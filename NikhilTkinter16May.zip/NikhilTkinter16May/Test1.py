from tkinter import *
from PIL import ImageTk,Image

root = Tk()
root.title("WElcome to skroman tech")
root.iconbitmap('D:/apply.ico')

MY_image = ImageTk.PhotoImage(Image.open("D:/na.png"))
my_label = Label(image=MY_image)
my_label.pack()



button_quit = Button(root, text="Exit", command=root.quit)
button_quit.pack()

root.mainloop()